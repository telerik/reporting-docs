﻿namespace AsyncAwaitDemo
{
    using System;
    using System.Collections;
    using System.Threading.Tasks;
    using Telerik.Reporting;
    using Telerik.Reporting.Processing;

    public class AsyncWrappers
    {
        // Wrap the RenderingResult like this:
        public async Task<RenderingResult> RenderReportAsync(Type reportType) // Pass parameters here, like device info and report to render
        {
            ReportProcessor reportProcessor = new ReportProcessor();

            // Set any deviceInfo settings if necessary
            Hashtable deviceInfo = new Hashtable();

            // Any other Report Source can be used instead
            // For example TypeReportSource can be used if the type of the report is passed as parameter of the method
            TypeReportSource typeReportSource = new TypeReportSource();

            typeReportSource.TypeName = reportType.AssemblyQualifiedName;

            return await Task.Run(() => reportProcessor.RenderReport("PDF", typeReportSource, deviceInfo));
        }
    }

}

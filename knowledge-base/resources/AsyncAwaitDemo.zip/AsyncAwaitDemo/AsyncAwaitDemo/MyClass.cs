﻿namespace AsyncAwaitDemo
{
    using System;
    using System.Threading;
    using System.Threading.Tasks;

    public class MyClass
    {
        //Use the wrapper in your code like this:
        public async Task<string> RenderReportAsync()
        {
            var asyncWrappers = new AsyncWrappers();

            Console.WriteLine("Rendering started on: {0}", Thread.CurrentThread.ManagedThreadId);

            var result = await asyncWrappers.RenderReportAsync(typeof(Telerik.Reporting.Report)); // pass the type of your report here

            string fileName = result.DocumentName + "." + result.Extension;
            string path = System.IO.Path.GetTempPath();
            string filePath = System.IO.Path.Combine(path, fileName);

            using (System.IO.FileStream fs = new System.IO.FileStream(filePath, System.IO.FileMode.Create))
            {
                fs.Write(result.DocumentBytes, 0, result.DocumentBytes.Length);
            }

            Console.WriteLine("Rendering finished on: {0}\n", Thread.CurrentThread.ManagedThreadId);

            // You can return void but that is not recommended
            return string.Format("Successfully rendered! File saved in {0}\n", filePath);
        }
    }
}

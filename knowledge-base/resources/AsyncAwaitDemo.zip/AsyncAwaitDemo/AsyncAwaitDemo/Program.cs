﻿namespace AsyncAwaitDemo
{
    using System;
    using System.Threading;

    class Program
    {
        // A working example
        static void Main(string[] args)
        {
            // Use your class to render the report in an async manner
            var myClass = new MyClass();

            Console.WriteLine("Starting rendering...");
            var task = myClass.RenderReportAsync();

            // While the report is rendering do something else
            Count();

            Console.WriteLine("Main finished on: {0}", Thread.CurrentThread.ManagedThreadId);
            Console.WriteLine("Render Status: {0}\n", task.Result);

            Console.ReadLine();
        }

        static void Count()
        {
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine(i);
            }
        }
    }
}

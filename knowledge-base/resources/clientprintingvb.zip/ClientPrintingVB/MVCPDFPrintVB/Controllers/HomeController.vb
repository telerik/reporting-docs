﻿Imports System.Web.Mvc

Public Class HomeController
    Inherits Controller

    ' GET: /Home
    Function Index() As ActionResult
        Return View()
    End Function

    Public Function GetPdf() As FileContentResult
        Dim reportProcessor = New Telerik.Reporting.Processing.ReportProcessor()
        Dim typeReportSource = New Telerik.Reporting.TypeReportSource()

        ' reportToExport is the Assembly Qualified Name of the report
        typeReportSource.TypeName = GetType(Report1).AssemblyQualifiedName
        Dim deviceInfo = New System.Collections.Hashtable()
        deviceInfo("JavaScript") = "this.print({bUI: true, bSilent: false, bShrinkToFit: true});"
        Dim result = reportProcessor.RenderReport("PDF", typeReportSource, deviceInfo)

        HttpContext.Response.AddHeader("content-disposition", "inline; filename=MyFile.pdf")
        Return File(result.DocumentBytes, "application/pdf")

    End Function
End Class
﻿Public Class WebForm1
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub Button1_Click(sender As Object, e As EventArgs)
        Dim reportProcessor = New Telerik.Reporting.Processing.ReportProcessor()
        Dim typeReportSource = New Telerik.Reporting.TypeReportSource()

        ' reportToExport is the Assembly Qualified Name of the report
        typeReportSource.TypeName = GetType(Report1).AssemblyQualifiedName
        Dim deviceInfo = New System.Collections.Hashtable()
        deviceInfo("JavaScript") = "this.print({bUI: true, bSilent: false, bShrinkToFit: true});"
        Dim result = reportProcessor.RenderReport("PDF", typeReportSource, deviceInfo)

        Me.Response.Clear()
        Me.Response.ContentType = result.MimeType
        Me.Response.Cache.SetCacheability(HttpCacheability.[Private])
        Me.Response.Expires = -1
        Me.Response.Buffer = True

        ' Uncomment to handle the file as attachment
        '             Response.AddHeader("Content-Disposition",
        '                            string.Format("{0};FileName=\"{1}\"",
        '                                            "attachment",
        '                                            fileName));
        '             


        Me.Response.BinaryWrite(result.DocumentBytes)
        Me.Response.End()
    End Sub
End Class
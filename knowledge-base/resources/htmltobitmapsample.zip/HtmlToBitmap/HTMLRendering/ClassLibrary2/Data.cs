using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;

namespace ClassLibrary2
{
    public class Item
    {
        string url;

        public string Url
        {
            get { return this.url; }
            set { this.url = value; }
        }

        public Item(string data)
        {
            this.url = data;
        }
    }

    public class Data: List<Item>
    {
        public Data()
        {
            for (int i = 0; i < 1; i++)
            {
                this.Add(new Item(@"<img alt='product logo' src='http://docs.telerik.com/devtools/aspnet-ajax/controls/editor/images/editor-productlogolight.gif' /> is the successor of the well known industry standard Editor for ASP.NET. The tight integration with ASP.NET AJAX and powerful new capabilities of the �Prometheus� suite features the new WYSIWYG Editor as a flexible and lightweight component, turning to be the fastest loading Web Editor. Among the hottest features are:
<ul>
    <li><em>Single-file, drag-and-drop deployment</em> </li>
    <li><em>Built on top of ASP.NET AJAX</em> </li>
    <li><em>Unmatched loading speed with new semantic rendering </em></li>
    <li><em>Full keyboard accessibility</em> </li>
    <li><em>Flexible Skinning mechanism</em> </li>
    <li><em>Simplified and intuitive toolbar configuration</em> </li>
    <li><em>Out-of-the-box XHTML-enabled output</em> </li>
</ul>
"));
            }
        }
    }
}

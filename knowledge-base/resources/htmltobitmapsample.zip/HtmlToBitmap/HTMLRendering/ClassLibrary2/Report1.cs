namespace ClassLibrary2
{
    using System.ComponentModel;
    using System.Drawing;
    using System.Collections.Generic;
    using System.Windows.Forms;
    using Telerik.Reporting;
    using Telerik.Reporting.Drawing;
    using System.Threading;
    using System.Collections;
    using System.IO;

    /// <summary>
    /// Summary description for Report1.
    /// </summary>
    public partial class Report1 : Report
    {
        public Report1()
        {
            /// <summary>
            /// Required for telerik Reporting designer support
            /// </summary>
            InitializeComponent();

            //
            // TODO: Add any constructor code after InitializeComponent call
            //
        }

        static public Image HTML2BitMap(string url, Telerik.Reporting.Processing.PictureBox me) 
        {
            Hashtable data = new Hashtable();
            data["url"] = url;
            data["image"] = null;
            // We expect PictureBox dimesions in pixels
            data["w"] = (int)me.Width.Value;
            data["h"] = (int)me.Height.Value;
            Thread t = new Thread(new ParameterizedThreadStart(Report1.GetImage));
			t.TrySetApartmentState(ApartmentState.STA);
            t.Start(data);
            t.Join();
            if (t.IsAlive)
                t.Abort();

            MemoryStream ms = new MemoryStream((byte[])data["image"]);
            Image img = Image.FromStream(ms);
            //Resize the PictureBox to the actual size of the browser image
            //me.Height = new Unit(img.Height,UnitType.Pixel);
            //me.Width = new Unit(img.Width, UnitType.Pixel);
            return img;
        }

        static public void GetImage(object _data)
        {
            Hashtable data = (Hashtable)_data;
            using (WebBrowser browser = new WebBrowser())
            {
                browser.ScrollBarsEnabled = false;
                // Set browser prefered size
                browser.Size = new Size((int)data["w"], (int)data["h"]);

                browser.DocumentText = (string)data["url"];
                while (browser.ReadyState != WebBrowserReadyState.Complete)
                    Application.DoEvents();

                Size sz = browser.Document.Body.ScrollRectangle.Size;

                using (Bitmap myBitmap = new Bitmap(sz.Width, sz.Height))
                {
                    browser.ClientSize = sz;

                    Rectangle drawRectangle = new Rectangle(0, 0, sz.Width, sz.Height);
                    browser.DrawToBitmap(myBitmap, drawRectangle);

                    MemoryStream ms = new MemoryStream();
                    myBitmap.Save(ms, System.Drawing.Imaging.ImageFormat.Png);

                    data["image"] = ms.ToArray();
                }
            }
        }
    }
}
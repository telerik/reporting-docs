﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebApplication1.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/
        public ActionResult Index()
        {
            return View();
        }

        public FileContentResult GetPdf()
        {
            var reportProcessor = new Telerik.Reporting.Processing.ReportProcessor();
            var typeReportSource = new Telerik.Reporting.TypeReportSource();

            // reportToExport is the Assembly Qualified Name of the report
            typeReportSource.TypeName = typeof(Report1).AssemblyQualifiedName;
            var deviceInfo = new System.Collections.Hashtable();
            deviceInfo["JavaScript"] = "this.print({bUI: true, bSilent: false, bShrinkToFit: true});";
            var result = reportProcessor.RenderReport("PDF", typeReportSource, deviceInfo);

            HttpContext.Response.AddHeader("content-disposition", "inline; filename=MyFile.pdf");
            return File(result.DocumentBytes, "application/pdf");

        }
    }
}
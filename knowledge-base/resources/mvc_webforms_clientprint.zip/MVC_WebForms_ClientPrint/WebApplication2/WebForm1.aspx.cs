﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication2
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            var reportProcessor = new Telerik.Reporting.Processing.ReportProcessor();
            var typeReportSource = new Telerik.Reporting.TypeReportSource();

            // reportToExport is the Assembly Qualified Name of the report
            typeReportSource.TypeName = typeof(Report1).AssemblyQualifiedName;
            var deviceInfo = new System.Collections.Hashtable();
            deviceInfo["JavaScript"] = "this.print({bUI: true, bSilent: false, bShrinkToFit: true});";
            var result = reportProcessor.RenderReport("PDF", typeReportSource, deviceInfo);

            this.Response.Clear();
            this.Response.ContentType = result.MimeType;
            this.Response.Cache.SetCacheability(HttpCacheability.Private);
            this.Response.Expires = -1;
            this.Response.Buffer = true;

            /* Uncomment to handle the file as attachment
             Response.AddHeader("Content-Disposition",
                            string.Format("{0};FileName=\"{1}\"",
                                            "attachment",
                                            fileName));
             */

            this.Response.BinaryWrite(result.DocumentBytes);
            this.Response.End();
        }
    }
}
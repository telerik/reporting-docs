<script setup lang="ts">
import { RouterLink, RouterView } from 'vue-router'
</script>

<template>
  <header>
    <div class="wrapper">
    </div>
  </header>
  <RouterView />
</template>

<style>
/* @import '@/assets/base.css'; */
</style>

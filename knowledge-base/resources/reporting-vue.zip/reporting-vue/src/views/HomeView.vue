<script setup lang="ts">
import WebReportDesigner from '../components/WebReportDesigner.vue'
</script>

<template>
  <main>
    <WebReportDesigner />
  </main>
</template>

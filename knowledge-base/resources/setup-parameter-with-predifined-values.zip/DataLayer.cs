﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Telerik.Reporting.Examples.CSharp
{
    class DataLayer
    {
        public IEnumerable<string> GetData()
        {
            return new List<string>{ "Value 1", "Value 2", "Value 3"};
        }

        public IEnumerable<string> ConvertToIEnumerable(string commaSeparatedData)
        {
            return commaSeparatedData.Split(',');
        }
    }
}

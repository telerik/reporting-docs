import React, { Component } from 'react';

export default class ReportViewer extends Component {

    componentDidMount() {
        window.jQuery('#reportViewer1')
            .telerik_ReportViewer({
                serviceUrl: 'https://demos.telerik.com/reporting/api/reports/',
                reportSource: {
                    report: 'ReportBook.trbp'
                },
                scale: 1.0,
                sendEmail: { enabled: true }
            });
    }

    render() {
        return <div id="reportViewer1"></div>
    }
}


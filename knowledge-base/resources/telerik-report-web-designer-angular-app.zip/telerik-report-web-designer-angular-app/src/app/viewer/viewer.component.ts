import { Component  } from '@angular/core';

declare var $: any;

@Component({
  selector: 'app-viewer-component',
  templateUrl: './viewer.component.html',
  styleUrls: ['./viewer.component.css']
})
export class ViewerComponent {
  viewer: null;

  ngOnInit(): void {
        this.viewer = $("#reportViewer").telerik_ReportViewer({
            serviceUrl: "https://demos.telerik.com/reporting/api/reports/",
            reportSource: {
                report: 'Telerik.Reporting.Examples.CSharp.ReportCatalog, CSharp.ReportLibrary, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null',
            parameters: {}
            }
        }).data("telerik_ReportViewer");
    }
}

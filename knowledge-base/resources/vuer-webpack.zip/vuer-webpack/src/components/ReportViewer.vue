<template>
  <div class="hello">
    <h1>{{ msg }}</h1>
    <div id="reportViewer1">loading...</div>
  </div>
</template>

<script>
import '../assets/ReportViewer/js/telerikReportViewer-12.2.18.912.min.js'

export default {
  name: 'ReportViewer',
  data () {
    return {
      msg: 'Welcome to Your Vue.js App'
    }
  },
  mounted () {
    this.$nextTick(function () {
      $('#reportViewer1')
        .telerik_ReportViewer({
          serviceUrl: 'https://demos.telerik.com/reporting/api/reports/',
          reportSource: {
            report: 'Telerik.Reporting.Examples.CSharp.ReportCatalog, CSharp.ReportLibrary'
          },
          viewMode: telerikReportViewer.ViewModes.INTERACTIVE,
          scaleMode: telerikReportViewer.ScaleModes.SPECIFIC,
          scale: 1.0,
          sendEmail: { enabled: true }
        })
    })
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
  body {
      font-family: Verdana, Arial;
      margin: 5px;
  }

  #reportViewer1 {
      position: absolute;
      top: 70px;
      bottom: 10px;
      left: 10px;
      right: 10px;
      overflow: hidden;
      clear: both;
  }
</style>
